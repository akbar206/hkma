from pathlib import Path
import re, html, mimetypes, urllib.request
from email.message import EmailMessage
from email import policy
import argparse
ROOT=Path(__file__).resolve().parent
URLS={1: 'https://www.hkpc.org/sites/default/files/2026-03/phishing_scams_impersonating_water_supplies_department_4_20260313.jpg', 2: 'https://www.hkcert.org/f/bulletin/914500/919246/320p482/WhatsApp-phishing-1.png', 4: 'https://oit.uccs.edu/sites/default/files/2020-01/ExamplePhishHoverMethod_0_0.png', 5: 'https://www.itsc.cuhk.edu.hk/images/content/privacy-security/phishing/mp/student-2pdvple.png'}
LABELS={1: 'Example of a fake Water Supplies Department notice (HKPC / HKCERT)', 2: 'Example of a fraudulent WhatsApp security page (HKCERT)', 3: 'Illustrative phishing email in Outlook format', 4: 'Hover over a link without clicking to reveal its destination (UCCS)', 5: 'Example of a parcel delivery phishing lure (CUHK)', 7: 'Step 1: Advanced > Report Spam', 8: 'Step 2: Reporting form; click OK'}
WIDTHS={1: 560, 2: 340, 3: 700, 4: 650, 5: 540, 7: 700, 8: 600}
parser=argparse.ArgumentParser(description="Build reminder HTML and an inline-image EML draft")
parser.add_argument('--fetch',action='store_true',help='Attempt to download missing public screenshots')
a=parser.parse_args()
def image_for(n):
    for ext in ('png','jpg','jpeg','gif'):
        p=ROOT/'images'/f'{n:02}.{ext}'
        if p.exists(): return p
    return None
if a.fetch:
    for n,url in URLS.items():
        if image_for(n): continue
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req,timeout=15) as r: data=r.read(15_000_001)
            if len(data)>15_000_000: raise ValueError('Image too large')
            ext='png' if data.startswith(b'\x89PNG\r\n\x1a\n') else 'jpg' if data.startswith(b'\xff\xd8\xff') else 'gif' if data.startswith(b'GIF8') else None
            if not ext: raise ValueError('Not a supported image')
            (ROOT/'images'/f'{n:02}.{ext}').write_bytes(data)
        except Exception as e: print(f'Image {n:02}: {e}')
files={n:image_for(n) for n in LABELS}
missing=[n for n,p in files.items() if not p]
source=(ROOT/'template.html').read_text(encoding='utf-8')
pattern=r'<td[^>]*><b>INSERT IMAGE (\d{2})</b>.*?</td>'
def render(mode):
    def replace(m):
        n=int(m.group(1)); p=files[n]; label=html.escape(LABELS[n]); w=WIDTHS[n]
        if not p:
            return f'<td style="border:1px dashed #9985A6;padding:16px;text-align:center;color:#62566B;"><b>IMAGE {n:02} — MISSING</b><br>{label}<br><a href="{html.escape(URLS.get(n,""),quote=True)}">Open source image (draft only)</a></td>'
        src=f'cid:reminder131-{n:02}' if mode=='cid' else 'images/'+p.name
        return f'<td align="center" style="padding:8px 0;"><img src="{src}" width="{w}" style="display:block;width:{w}px;max-width:100%;height:auto;border:0;" alt="{label}"><br><span style="font-size:12px;color:#555;">{label}</span></td>'
    result,count=re.subn(pattern,replace,source,flags=re.S)
    if count!=7: raise ValueError(f'Expected 7 image slots, found {count}')
    return result
(ROOT/'IT_Security_Reminder_131.html').write_text(render('local'),encoding='utf-8')
if missing:
    print('Preview created. Missing images:', ', '.join(f'{n:02}' for n in missing))
    print('Save them in images/ and run again. No send-ready EML generated.')
    raise SystemExit(0)
msg=EmailMessage(policy=policy.SMTP)
msg['Subject']='IT Security Reminder #131 – Phishing Awareness'
msg['X-Unsent']='1'
msg.set_content('Please view this reminder in HTML format.')
msg.add_alternative(render('cid'),subtype='html')
part=msg.get_payload()[-1]
for n,p in files.items():
    mt=mimetypes.guess_type(p.name)[0] or 'image/jpeg'
    part.add_related(p.read_bytes(),maintype='image',subtype=mt.split('/')[1],cid=f'<reminder131-{n:02}>',disposition='inline',filename=p.name)
(ROOT/'IT_Security_Reminder_131.eml').write_bytes(msg.as_bytes())
print('HTML and EML draft created. Open EML in Outlook and test before sending.')
