1. Extract ZIP to an approved work folder. Do not transfer internal screenshots outside approved systems.
2. Run python build_reminder.py --fetch to attempt downloading four public images. Verify reuse permission.
3. Save missing public images using IMAGE_SOURCES.txt.
4. Add new reporting screenshots as images/07.jpg and images/08.jpg (or PNG).
5. Run python build_reminder.py. It generates HTML and, when all seven images exist, an EML with inline CID images.
6. Open EML in Outlook and send a test to yourself. If read-only, copy HTML into a new message and insert pictures manually.
7. Previous simulation themes and wording still require internal verification. Image 06 intentionally removed.
