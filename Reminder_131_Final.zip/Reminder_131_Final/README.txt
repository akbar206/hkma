IT SECURITY REMINDER #131 — Revision of 27 November 2026

1. Extract this ZIP into an approved work folder. Do not transfer internal screenshots outside approved systems.
2. Copy your two existing reporting screenshots into images/ as 07.jpg and 08.jpg (PNG or JPEG also accepted; remove any older same-number files). Redact personal data where needed.
3. In PowerShell, open the folder containing build_reminder.py and run:
   python build_reminder.py
   If needed, use: py build_reminder.py
4. Open IT_Security_Reminder_131.html for a browser preview. Once all five images are present, the script also generates IT_Security_Reminder_131.eml with embedded inline images.
5. Open the EML in Outlook and test the appearance before sending. If read-only, copy the browser preview into a new HTML email and insert pictures locally as needed.

No downloads or external libraries are needed. Images 04, 05 and 06 are intentionally removed. Images 07 and 08 are intentionally absent from the package. Verify the VDI label appearance, statistic sources and permission to reuse the two external screenshots before distribution. The new illustrations are original training mockups, not actual emails. The separate parcel illustration has been removed; parcel delivery remains a lure and review question.
