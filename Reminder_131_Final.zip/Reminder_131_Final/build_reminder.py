from pathlib import Path
import re
import html
from email.message import EmailMessage
from email import policy

ROOT = Path(__file__).resolve().parent
LABELS = {
    1: 'PHISHING EXAMPLE: Page impersonating the Water Supplies Department',
    2: 'PHISHING EXAMPLE: Page impersonating the WhatsApp Security Centre',
    3: 'Illustrative phishing email — five warning signs, hover preview and four response steps',
    7: 'Step 1: Advanced > Report Spam',
    8: 'Step 2: Reporting form; click OK',
}
WIDTHS = {1: 560, 2: 340, 3: 720, 7: 700, 8: 600}

def image_for(n):
    for ext in ('png', 'jpg', 'jpeg', 'gif'):
        p = ROOT / 'images' / f'{n:02}.{ext}'
        if p.is_file():
            data = p.read_bytes()
            subtype = ('png' if data.startswith(b'\x89PNG\r\n\x1a\n') else
                       'jpeg' if data.startswith(b'\xff\xd8\xff') else
                       'gif' if data.startswith(b'GIF8') else None)
            if subtype:
                return p, data, subtype
            print(f'Unsupported image: {p.name}. Save as a valid PNG or JPEG.')
    return None

files = {n: image_for(n) for n in LABELS}
missing = [n for n, entry in files.items() if entry is None]
source = (ROOT / 'template.html').read_text(encoding='utf-8')
pattern = r'<td[^>]*><b>INSERT IMAGE (\d{2})</b>.*?</td>'

def render(mode):
    def replace(m):
        n = int(m.group(1)); entry = files[n]
        label = html.escape(LABELS[n]); w = WIDTHS[n]
        if not entry:
            return f'<td style="border:1px dashed #9985A6;padding:16px;text-align:center;color:#62566B;font-size:16px;"><b>IMAGE {n:02} — MISSING</b><br>{label}<br>Add the screenshot locally before sending.</td>'
        p, _, _ = entry
        src = f'cid:reminder131-{n:02}' if mode == 'cid' else 'images/' + p.name
        caption = f'<br><span style="font-family:Arial,Helvetica,sans-serif;font-size:16px;color:{"#A72C32" if n in (1,2) else "#25232A"};font-weight:bold;">{label}</span>'
        return f'<td align="center" style="padding:8px 0 12px;"><img src="{src}" width="{w}" style="display:block;width:{w}px;max-width:100%;height:auto;border:0;" alt="{label}">{caption}</td>'
    result, count = re.subn(pattern, replace, source, flags=re.S)
    if count != len(LABELS):
        raise ValueError(f'Expected {len(LABELS)} image slots, found {count}')
    return result

(ROOT / 'IT_Security_Reminder_131.html').write_text(render('local'), encoding='utf-8')
eml = ROOT / 'IT_Security_Reminder_131.eml'
if missing:
    eml.unlink(missing_ok=True)
    print('HTML preview created. Missing images:', ', '.join(f'{n:02}' for n in missing))
    print('Save them in images/ and run again. No send-ready EML generated.')
    raise SystemExit(0)

msg = EmailMessage(policy=policy.SMTP)
msg['Subject'] = 'IT Security Reminder #131 – Phishing Awareness / Latest Trends and Techniques'
msg['X-Unsent'] = '1'
msg.set_content('Please view this reminder in HTML format.')
msg.add_alternative(render('cid'), subtype='html')
part = msg.get_payload()[-1]
for n, (p, data, subtype) in files.items():
    part.add_related(data, maintype='image', subtype=subtype, cid=f'<reminder131-{n:02}>', disposition='inline', filename=p.name)
eml.write_bytes(msg.as_bytes())
print('HTML and EML draft created. Open EML in Outlook and test before sending.')
